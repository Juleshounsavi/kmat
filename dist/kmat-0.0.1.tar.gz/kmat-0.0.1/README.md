# kmat: a little package for matrix operations.
It's like a sub package of math, it contains functions like:
    -Matmin
    -Matmax
    -Matsize
    -Matdet
    -Matranspo
